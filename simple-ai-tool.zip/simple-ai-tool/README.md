# Simple ai tool 

A Pen created on CodePen.

Original URL: [https://codepen.io/Nandhini-Suresh-the-styleful/pen/QwjPbGx](https://codepen.io/Nandhini-Suresh-the-styleful/pen/QwjPbGx).

